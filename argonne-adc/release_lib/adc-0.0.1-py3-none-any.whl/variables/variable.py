createStudy = """{"name": "Test Study Name", "description": "Test Study Description", "keywords": ["test", "graphql", "demo", "argonne"]}"""
createInvestigation = """{"name": "Test Study Name",
    "description": "Test Study Description",
    "keywords": ["test", "graphql", "demo", "argonne"],
    "sampleGlobalIds" : ["VXNlck5vZGU6Mg=="],
    "studyGlobalId": "U3R1ZHlOb2RlOjE="
}"""
